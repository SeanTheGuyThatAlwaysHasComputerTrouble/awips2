cp loader/testraster.tif loader/Basic.tif
