-- #1485
SELECT '#1485', count(*) FROM geometry_columns
WHERE f_table_name = 'raster_columns';
