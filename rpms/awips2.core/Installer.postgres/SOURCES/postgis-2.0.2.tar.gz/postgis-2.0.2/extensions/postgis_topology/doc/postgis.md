PostGIS 2.0.0
============

Extensive documentation can be found at.
HTML: http://www.postgis.org/documentation/manual-svn/
PDF: http://www.postgis.org/download/postgis-2.0.0SVN.pdf
