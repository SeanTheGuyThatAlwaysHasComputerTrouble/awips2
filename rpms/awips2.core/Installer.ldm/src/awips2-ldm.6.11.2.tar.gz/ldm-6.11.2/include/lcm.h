/* $Id: lcm.h,v 1.1 1995/04/06 00:07:10 davis Exp $ */

#ifndef _LCM_H_
#define _LCM_H_

extern unsigned long
gcd(unsigned long mm, unsigned long nn);

extern unsigned long
lcm(unsigned long mm, unsigned long nn);

#endif /*!_LCM_H_*/
