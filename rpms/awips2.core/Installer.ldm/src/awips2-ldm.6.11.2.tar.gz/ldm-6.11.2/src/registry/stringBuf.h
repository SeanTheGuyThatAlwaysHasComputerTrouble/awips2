/*
 *   See file ../COPYRIGHT for copying and redistribution conditions.
 *
 *   This header-file specifies the API for string buffers.
 *   The methods of this module are thread-compatible but not thread-safe.
 */
#ifndef STRING_BUF_H
#define STRING_BUF_H

typedef struct stringBuf        StringBuf;

#include "registry.h"

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Returns a new instance of a string-buffer.
 *
 * Arguments:
 *      buf             Pointer to a pointer to the new buffer.  Shall not be
 *                      NULL.  Set upon successful return.  The client should
 *                      call "sb_free()" when the string-buffer is no longer
 *                      needed.
 *      nchar           Initial maximum number of characters.
 * Returns:
 *      0               Success.  "*buf" is set.
 *      ENOMEM   System error.  "log_start()" called.
 */
RegStatus sb_new(
    StringBuf** const   buf,
    const size_t        nchar);

/*
 * Frees a string-buffer.
 *
 * Arguments:
 *      strBuf          Pointer to a string-buffer.  May be NULL.  Upon return,
 *                      the client shall not dereference "strBuf".
 */
void sb_free(
    StringBuf* const    strBuf);

/*
 * Ensures that a string-buffer can contain a given number of bytes.
 *
 * Arguments:
 *      strBuf          Pointer to the string-buffer.  Shall not be NULL.
 *      len             The number of bytes that the string-buffer must contain
 *                      (excluding the terminating NUL)
 * Returns:
 *      0               Success
 *      ENOMEM   System error.  "log_start()" called.
 */
RegStatus sb_ensure(
    StringBuf* const    strBuf,
    const size_t        len);

/*
 * Sets a string-buffer to the concatenation of a sequence of strings.
 *
 * Arguments:
 *      strBuf          Pointer to the string-buffer to be set.  Shall not be
 *                      NULL.
 *      ...             Pointers to strings to be concatenated, in order, to
 *                      the string-buffer.  None shall be NULL except the last
 *                      pointer which shall be NULL.
 * Returns:
 *      0               Success
 *      ENOMEM          System error.  "log_start()" called.
 */
RegStatus sb_set(
    StringBuf* const    strBuf,
    ...);

/*
 * Sets a string-buffer to the first "n" bytes of a string.
 *
 * Arguments:
 *      strBuf          Pointer to the string-buffer to be set.  Shall not be
 *                      NULL.
 *      string          Pointer to the string with which to set the buffer.
 *                      Shall not be NULL.
 *      nbytes          Number of bytes of the string to use (excluding
 *                      terminating NUL).
 * Returns:
 *      0               Success
 *      ENOMEM   System error.  "log_start()" called.
 */
RegStatus sb_nset(
    StringBuf* const    strBuf,
    const char* const   string,
    size_t              nbytes);

/*
 * Appends strings to a string-buffer.
 *
 * Arguments:
 *      strBuf          Pointer to the string-buffer to be appended to.  Shall
 *                      not be NULL.
 *      ...             Pointers to strings to be appended, in order, to
 *                      the string-buffer.  None shall be NULL except the last
 *                      pointer which shall be NULL.
 * Returns:
 *      0               Success
 *      ENOMEM   System error.  "log_start()" called.
 */
RegStatus sb_cat(
    StringBuf* const    strBuf,
    ...);

/*
 * Trims a string-buffer to a given length.
 *
 * Arguments:
 *      strBuf          Pointer to the string-buffer.
 *      len             The maximum number of bytes to retain.  If greater than
 *                      or equal to the length of the string, then nothing
 *                      happens; otherwise, the string is truncated to the
 *                      given number of bytes.
 */
void sb_trim(
    StringBuf* const    strBuf,
    const size_t        len);

/*
 * Returns the string of a string-buffer.
 *
 * Arguments:
 *      strBuf          Pointer to the string-buffer.  Shall not be NULL.
 * Returns:
 *      Pointer to the NUL-terminated string.  The client shall not modify or
 *      free.
 */
const char* sb_string(
    const StringBuf* const      strBuf);

/*
 * Returns the length of the string of a string-buffer (excluding the 
 * terminating NUL).
 *
 * Arguments:
 *      strBuf          Pointer to the string-buffer.  Shall not be NULL.
 * Returns:
 *      The number of bytes in the string (excluding the terminating NUL)
 */
size_t sb_len(
    const StringBuf* const      strBuf);

#ifdef __cplusplus
}
#endif

#endif
