int dummy_linking_variable = 0;
