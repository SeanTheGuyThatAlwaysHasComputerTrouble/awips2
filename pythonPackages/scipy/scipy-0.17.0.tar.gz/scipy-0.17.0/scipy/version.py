
# THIS FILE IS GENERATED FROM SCIPY SETUP.PY
short_version = '0.17.0'
version = '0.17.0'
full_version = '0.17.0'
git_revision = '4b17e2bcbed2ef65cd14923a1ed5d1ccb6d8f8aa'
release = True

if not release:
    version = full_version
