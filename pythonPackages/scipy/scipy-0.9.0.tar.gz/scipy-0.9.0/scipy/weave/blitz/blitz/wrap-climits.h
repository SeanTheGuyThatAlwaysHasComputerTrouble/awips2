#ifndef BZ_WRAP_CLIMITS_H
#define BZ_WRAP_CLIMITS_H

#ifdef BZ_HAVE_CLIMITS
 #include <climits>
#else
 #include <limits.h>
#endif

#endif
